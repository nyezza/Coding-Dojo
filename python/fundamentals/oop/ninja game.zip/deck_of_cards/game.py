from classes.deck import Deck
from classes.card import Card

bicycle = Deck()

bicycle.show_cards()


trefle=Card("trefle",10,"queen")
trefle.card_info()